package com.munni.keyboard

import android.inputmethodservice.InputMethodService
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.VideoView

class MunniKeyboardService : InputMethodService() {
    private var videoView: VideoView? = null
    private var bengali = true

    override fun onCreateInputView(): View {
        val prefs = getSharedPreferences("munni_keyboard", MODE_PRIVATE)
        val frame = FrameLayout(this)
        frame.setBackgroundColor(0xFF102C28.toInt())

        val savedVideo = prefs.getString("video_uri", null)
        if (!savedVideo.isNullOrBlank()) {
            try {
                videoView = VideoView(this).apply {
                    setVideoURI(Uri.parse(savedVideo))
                    setOnPreparedListener { player -> player.isLooping = true; start() }
                    setOnErrorListener { _, _, _ -> true }
                }
                frame.addView(videoView, FrameLayout.LayoutParams(-1, -1))
            } catch (_: Exception) { }
        }

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(5, 5, 5, 8)
            setBackgroundColor(0xB809201C.toInt())
        }
        val toolbar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        toolbar.addView(makeButton(if (bengali) "বাংলা" else "English") { bengali = !bengali; recreateInputView() }, LinearLayout.LayoutParams(0, 44, 1f))
        toolbar.addView(makeButton("⚙ Theme") { requestShowSelf(0) }, LinearLayout.LayoutParams(0, 44, 1f))
        toolbar.addView(makeButton("⌫") { currentInputConnection?.deleteSurroundingText(1, 0) }, LinearLayout.LayoutParams(0, 44, 1f))
        panel.addView(toolbar)

        val rows = if (bengali) listOf(
            listOf("১","২","৩","৪","৫","৬","৭","৮","৯","০"),
            listOf("ক","খ","গ","ঘ","ঙ","চ","ছ","জ","ঝ","ঞ"),
            listOf("ট","ঠ","ড","ঢ","ণ","ত","থ","দ","ধ","ন"),
            listOf("প","ফ","ব","ভ","ম","য","র","ল","শ","ষ"),
            listOf("স","হ","া","ি","ী","ু","ূ","ে","ো","ঁ")
        ) else listOf(
            listOf("q","w","e","r","t","y","u","i","o","p"),
            listOf("a","s","d","f","g","h","j","k","l"),
            listOf("z","x","c","v","b","n","m")
        )
        rows.forEach { row ->
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
            row.forEach { key -> line.addView(makeButton(key) { currentInputConnection?.commitText(key, 1) }, LinearLayout.LayoutParams(0, 47, 1f).apply { setMargins(2, 2, 2, 2) }) }
            panel.addView(line)
        }
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        bottom.addView(makeButton("?123") { currentInputConnection?.commitText("123", 1) }, LinearLayout.LayoutParams(0, 48, 1f))
        bottom.addView(makeButton("বাংলা/EN") { bengali = !bengali; recreateInputView() }, LinearLayout.LayoutParams(0, 48, 1f))
        bottom.addView(makeButton("Space") { currentInputConnection?.commitText(" ", 1) }, LinearLayout.LayoutParams(0, 48, 2f))
        bottom.addView(makeButton("↵") { currentInputConnection?.commitText("\n", 1) }, LinearLayout.LayoutParams(0, 48, 1f))
        panel.addView(bottom)
        frame.addView(panel, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        return frame
    }

    private fun makeButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        textSize = 15f
        isAllCaps = false
        setTextColor(0xFFFFFFFF.toInt())
        setBackgroundColor(0xCC087F68.toInt())
        setOnClickListener { action() }
        minWidth = 0
        minimumWidth = 0
        minimumHeight = 0
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        videoView?.stopPlayback()
        videoView = null
        super.onFinishInputView(finishingInput)
    }
}
