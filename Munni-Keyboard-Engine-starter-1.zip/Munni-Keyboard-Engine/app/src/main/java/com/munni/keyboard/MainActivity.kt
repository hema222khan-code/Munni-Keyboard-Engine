package com.munni.keyboard

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("munni_keyboard", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
            setBackgroundColor(0xFF071C19.toInt())
        }
        val title = TextView(this).apply {
            text = "Munni-Keyboard Engine"
            textSize = 26f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "বাংলা • English • Video Themes"
            textSize = 15f
            setTextColor(0xFFB8D8D0.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 28)
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(actionButton("১. Enable keyboard") { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) })
        root.addView(actionButton("২. Choose Munni keyboard") {
            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showInputMethodPicker()
        })
        root.addView(actionButton("Choose video from gallery") { openVideoPicker() })
        root.addView(actionButton("Clear video theme") {
            prefs.edit().remove("video_uri").apply()
            Toast.makeText(this, "Video theme cleared", Toast.LENGTH_SHORT).show()
        })
        val note = TextView(this).apply {
            text = "Starter build: basic keyboard + personal video background. Advanced Bengali layouts, voice typing, scanner and audio transcription are planned modules."
            textSize = 13f
            setTextColor(0xFFB8D8D0.toInt())
            setPadding(0, 24, 0, 0)
            gravity = Gravity.CENTER
        }
        root.addView(note)
        setContentView(root)
    }

    private fun actionButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 8, 0, 8) }
    }

    private fun openVideoPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "video/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, 41)
    }

    @Deprecated("Legacy activity result used for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 41 && resultCode == RESULT_OK) {
            data?.data?.let { uri: Uri ->
                try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
                prefs.edit().putString("video_uri", uri.toString()).apply()
                Toast.makeText(this, "Video theme saved. Open the keyboard to preview.", Toast.LENGTH_LONG).show()
            }
        }
    }
}
