# Munni-Keyboard Engine (starter project)

A native Android Input Method Editor (IME) starter written in Kotlin.

## Included in this first scaffold
- Android app shell with setup instructions for enabling the keyboard.
- Basic custom InputMethodService keyboard with Bengali and English key layouts.
- Select a personal video from the device using Android's document picker.
- Saved video URI is used as a looping background while the keyboard is visible.
- Video playback is stopped when the keyboard view closes.

## Important limitations
This is an early starter scaffold, not a release-ready keyboard. The Bengali key layout is a basic key grid, not a full phonetic transliteration engine. Avro phonetic conversion, official Provat/Jatiyo mappings, voice input, PDF scanning, audio transcription, theme library, accessibility testing, and privacy/security review still need implementation. Do not publish this build as a finished product.

## Build
Open this folder in Android Studio (Giraffe or newer), install Android SDK Platform 35, then Sync Gradle and run on an Android device/emulator. Android Studio can generate the Gradle wrapper if it is missing.

## Enable the keyboard
1. Install and open the app.
2. Tap Enable keyboard and enable Munni-Keyboard Engine in Android settings.
3. Return to the app and tap Choose Munni keyboard.
4. Optionally choose a video from the gallery, then open any text field to preview the keyboard.

## Privacy design goals
- No network permission is declared in this scaffold.
- No typed text is collected or transmitted.
- Video is selected through Android's system document picker and its URI is stored locally.
- Before adding cloud speech recognition or analytics, obtain explicit consent and document data handling.

## Planned Google login (not yet enabled)
The requested first-launch Google sign-in will use Firebase Authentication and a Firebase UID as each user's unique ID. This feature is not implemented in this starter yet: there is no Firebase project configuration, `google-services.json`, or sign-in dependency configured. To enable it, create/register the Firebase Android app, enable the Google provider, add `google-services.json`, and configure debug/release SHA-1 and SHA-256 fingerprints. Never collect or transmit typed keyboard text as part of authentication.
