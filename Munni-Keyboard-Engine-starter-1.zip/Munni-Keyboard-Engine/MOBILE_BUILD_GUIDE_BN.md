# শুধু Android ফোন দিয়ে APK বানানোর গাইড

এই প্রজেক্টটি Android Studio-এর Kotlin/Gradle সোর্স। Android ফোনে ZIP extract করলেই APK তৈরি হয় না। কম্পিউটার ছাড়া GitHub Actions-এর ক্লাউড বিল্ড ব্যবহার করা যায়।

1. Chrome-এ github.com খুলে নিজের অ্যাকাউন্টে সাইন ইন করো।
2. New repository তৈরি করো; নাম `Munni-Keyboard-Engine` দাও; Private রাখাই ভালো।
3. Extract করা ফোল্ডারের ভেতরের সব ফাইল ও ফোল্ডার (যেমন `app`, `gradle.properties`, `settings.gradle.kts`, `.github`) repository-তে আপলোড করো। বাইরের `Munni-Keyboard-Engine` ফোল্ডারটিকে আরেকটি স্তর হিসেবে আপলোড কোরো না; এর ভেতরের জিনিসগুলো repository root-এ থাকবে।
4. Repository-র Actions ট্যাব খোলো। `Build Munni Keyboard APK` workflow বেছে `Run workflow` চাপো।
5. কাজ শেষ হলে সবুজ সফল run খুলে Artifacts থেকে `Munni-Keyboard-Engine-debug` ZIP ডাউনলোড করো।
6. ওই ZIP extract করে `app-debug.apk` ফাইলে চাপ দিয়ে Android-এর অনুমতি অনুযায়ী install করো।

নোট: এটি debug/test APK, Play Store release নয়। Google/Firebase login এখনো কোডে যুক্ত করা হয়নি। APK ইনস্টল করার আগে শুধু নিজের তৈরি/বিশ্বস্ত build ব্যবহার করো।
