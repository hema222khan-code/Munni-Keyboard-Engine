# Product roadmap

## MVP
1. Stable IME lifecycle, key events, delete, enter, shift, symbols, suggestions.
2. Bengali layouts: National, Provat, and phonetic transliteration with test corpus.
3. Theme Studio: static photo, colors, gradients, opacity, video loop, mute, crop/fit, battery-aware pause.
4. Settings, onboarding, permissions education, privacy policy.

## Feature modules
- Voice typing: explicit microphone permission and clear on-device/cloud processing choice.
- PDF scanner: camera capture, crop, page ordering, local PDF export.
- Audio-to-text: user-selected audio files; transcription engine and language support to be selected.
- Emoji/sticker panel and clipboard controls.

## Quality gates
- Test across Android versions, screen sizes, landscape, password fields, and major apps.
- Ensure video stops when IME is hidden and pauses appropriately when app is backgrounded.
- Do not log or transmit keystrokes; avoid collecting sensitive text.
- Accessibility, performance, memory, battery, and security review before release.

## Account and sign-in (new requirement)
- First launch opens an authentication gate before the app's main dashboard.
- Primary sign-in: Google account picker (users can choose any Google/Gmail account on their device).
- Use Firebase Authentication with Google sign-in; use Firebase UID as the stable, unique user ID. Do not ask users to invent or share a password for Google sign-in.
- Persist the authenticated session securely using the supported Firebase session; provide sign-out and account-switching.
- Store only the minimum profile fields needed: Firebase UID, display name, email, optional profile photo URL, and account-created timestamp.
- Never collect, log, upload, or inspect typed keyboard content. Authentication is separate from the IME input pipeline.
- Do not request Contacts, SMS, or broad storage access for sign-in. Explain any optional permissions separately.
- Firebase setup is required before Google sign-in can work: create a Firebase project, register the Android application/package name, enable Google provider, add the generated `google-services.json`, and configure the signing certificate fingerprints (debug and release SHA-1/SHA-256).
- Test first-run, cancellation, offline/error states, returning sessions, sign-out, account switching, and revoked/expired sessions.

### Authentication implementation status
This is a planned integration, not yet a working login implementation. The current starter has no Firebase configuration or authentication dependencies. Do not display a fake successful login; wire the UI only after Firebase credentials/configuration are supplied.
